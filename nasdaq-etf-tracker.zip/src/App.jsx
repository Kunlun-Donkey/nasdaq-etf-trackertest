import React from "react";
import NasdaqETFTracker from "./components/NasdaqETFTracker";

function App() {
  return <NasdaqETFTracker />;
}

export default App;