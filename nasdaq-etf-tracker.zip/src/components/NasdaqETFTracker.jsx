import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

const mockData = {
  date: "2025-04-11",
  nasdaqFutures: "+0.45%",
  usdCny: "贬值 0.2%",
  qqqAfterHours: "+0.38%",
  forecast: "上涨",
};

export default function NasdaqETFTracker() {
  return (
    <div className="grid place-items-center min-h-screen bg-gray-50 p-4">
      <Card className="w-full max-w-md shadow-xl rounded-2xl">
        <CardContent className="p-6 space-y-4">
          <h1 className="text-xl font-bold text-center">159541 纳指ETF 走势预判</h1>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>日期</span>
              <span>{mockData.date}</span>
            </div>
            <div className="flex justify-between">
              <span>纳指期货涨跌</span>
              <span>{mockData.nasdaqFutures}</span>
            </div>
            <div className="flex justify-between">
              <span>美元/人民币变动</span>
              <span>{mockData.usdCny}</span>
            </div>
            <div className="flex justify-between">
              <span>QQQ盘后表现</span>
              <span>{mockData.qqqAfterHours}</span>
            </div>
            <div className="flex justify-between items-center">
              <span>预期ETF方向</span>
              <Badge
                variant={mockData.forecast === "上涨" ? "default" : "secondary"}
                className={\`text-white px-3 py-1 rounded-full text-sm flex items-center space-x-1 \${mockData.forecast === "上涨" ? "bg-green-500" : "bg-red-500"}\`}
              >
                {mockData.forecast === "上涨" ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                <span>{mockData.forecast}</span>
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}